# ravn-trio

Trío PM/WK/RV local en tabs de [herdr](https://herdr.dev): repo de código del dúo `ravn-trio` / `ravn-trio-arch` (Arquetipo A). Spec: robert-flo/PJ-NIRI-rf-omarchy-workstation#58.

## Instalación

```bash
make check                      # shellcheck + tests
sudo make install               # /usr/bin/pj-trio y /usr/share/ravn/trio/
make DESTDIR=pkg install        # para empaquetar
```

Para usarlo desde el checkout: `./pj-trio …` (busca los helpers junto a sí mismo).

Requiere `herdr` ≥ 0.9.5, `jq`, `git` y `notify-send` (libnotify).

## Estructura (lenguaje de diseño de git-setup)

```text
├── pj-trio                  # Launcher: despacha por runtime/commands.tsv; sin subcomando → start
├── trio-status              # Alias de `pj-trio status` (lo invoca el PM)
├── trio-pm-prompt.md        # Plantilla del arranque del PM
├── trio.conf.example        # Defaults: kinds por rol, identidad git, integración herdr
└── runtime/
    ├── commands.tsv         # Catálogo: start, kickoff, status, help
    ├── completion/pj-trio.bash
    ├── helper/set_variable.sh
    ├── lib/                 # presentation, command_catalog, command_interface, dispatch,
    │                        # lifecycle (idénticos a git-setup) + trio_project/config/herdr
    └── scripts/             # start, kickoff, status, help
```

Instalado: todo bajo `/usr/share/ravn/trio/` y `/usr/bin/pj-trio` → symlink al launcher.

## Configuración

`trio.conf` se lee por capas y la última gana: defaults (`/usr/share/ravn/trio/trio.conf`, si no `trio.conf.example`) → override de la máquina en `/zt/ravn/trio/trio.conf` (`TRIO_OVERRIDE_DIR`) → repo (`<proyecto>/.trio/trio.conf`). `PJ_TRIO_CONFIG` reemplaza todas las capas. Nada en `$HOME`.

## Plugin de herdr

`herdr-plugin.toml` declara la acción **New trio** (`ravn.trio.new-trio`) y un link handler para URLs de issues de GitHub. La acción toma el ticket de la URL clicada o del número seleccionado y el proyecto del worktree o cwd del panel, y corre `pj-trio`. Para enlazarlo: `herdr plugin link /usr/share/ravn/trio` (o el checkout).

## `pj-trio`

`pj-trio` es un inicializador idempotente para herdr que prepara un workspace con tres tabs dedicados e independientes a pantalla completa para los roles del trío: **PM**, **WK** y **RV**.

### Uso

```bash
pj-trio [--dry-run] [--no-kickoff] [--print-kickoff] <proyecto> <ticket> [--repo <miembro>] [--base <rama>]
```

- `<proyecto>`: Ruta al checkout git del proyecto meta (`pj-*` o un home repo `HR-*`) o nombre del directorio. Si pasás únicamente el nombre, se resuelve contra la variable de entorno `$PJ_TRIO_ROOT`, o por defecto contra el directorio padre de `$PWD` y `$PJ_TRIO_ROOTS` (default `/z-drive/tries /z-home-repos /z/repos`: clones de try, home repos `/z-home-repos/<HR-X>` y raíces de worktrees de ravn-git-bare-clone).
- `<ticket>`: Identificador del issue o ticket a trabajar (por ejemplo `18` o `999`).
- `--repo <miembro>`: Repositorio miembro opcional, donde vive el issue. Acepta ruta, nombre del directorio, nombre del repo en GitHub (`pj-domina-rf-git-setup` o `robert-flo/pj-domina-rf-git-setup`) o nombre corto único (`rf-git-setup`). Se busca siempre igual, sin depender de `$PWD`: subdirectorios del proyecto (layout de try-clone, `rf-<nombre>`), hermanos y las raíces `$PJ_TRIO_ROOTS` (default `/z-drive/tries`, con el prefijo de fecha de `try clone`). El PM lee el issue con `gh issue view <ticket> -R <dueño>/<miembro>` y el handoff/agentes usan la clave `<miembro>-<ticket>` (no choca el #4 de dos miembros). Los agentes abren en el clon del miembro y el meta-repo se les añade con `--add-dir`.
- Proyecto meta ausente: si `<proyecto>` es un nombre (o `dueño/nombre`) que no está en las raíces, `pj-trio` avisa y clona **solo ese** meta-repo con try-clone (`PJ_TRIO_CLONE_CMD`, default `try exec --path {root} clone {url} | bash`, en la primera raíz de `$PJ_TRIO_ROOTS`; dueño `PJ_TRIO_OWNER`, default `robert-flo`) y sigue. En `--dry-run` solo muestra el comando; `PJ_TRIO_NO_CLONE=1` lo desactiva.
- `--base <rama>`: Rama del spec cuando el ticket es un sub-issue (ADR 0006 de pj-template): el worktree del WK sale de `origin/<rama>` y su PR va contra `<rama>`. Sin `--base` (un trivial), sale de `origin/HEAD` y el PR va a la rama por defecto. Acepta `origin/<rama>`. Como la base termina en comandos que corre el PM, solo se aceptan letras, números, `.`, `_`, `/` y `-` (`^[A-Za-z0-9][A-Za-z0-9._/-]*$`), además de `git check-ref-format --branch`. La rama tiene que existir en `origin` del miembro (ref exacta: `git ls-remote --exit-code origin refs/heads/<rama>`): si no existe, `pj-trio` falla antes de abrir los tabs.
- `--dry-run`: Muestra los comandos y la topología sin aplicarlos.
- `--no-kickoff`: No envía el prompt de arranque al PM.
- `--print-kickoff`: Imprime el prompt de arranque renderizado y sale (para pegarlo a mano).

### Disposición de Tabs (Topología)

En lugar de dividir un único tab en paneles pequeños, `pj-trio` crea o reutiliza tres tabs en herdr a pantalla completa dentro del workspace, garantizando que cada agente tenga el espacio completo de terminal sin splits:

- **pm**: Tab raíz para la coordinación y gestión del ticket. Panel etiquetado como `PM-<ticket>`, con agente `pm-<miembro corto>-<ticket>`.
- **wk**: Tab dedicado a la implementación de cambios y código. Panel etiquetado como `WK-<ticket>`, con agente `wk-<proyecto>-<ticket>`.
- **rv**: Tab dedicado a la revisión técnica y validación de entregas. Panel etiquetado como `RV-<ticket>`, con agente `rv-<proyecto>-<ticket>`.

El directorio de trabajo (`cwd`) de los tres tabs es el clon del miembro si pasás `--repo`, y el meta-repo (`pj-*`) si no. Con `--repo`, el meta-repo (donde vive `.trio/`) se añade a cada agente con `--add-dir <meta-repo>`.

### Etiquetado de Workspace

La etiqueta del espacio de trabajo se genera automáticamente:
- Sin `--repo`: `trio <proyecto>#<ticket>`
- Con `--repo`: `trio <proyecto>/<miembro>#<ticket>`

`<proyecto>` sale de `proyecto:` en `proyecto.yml` (o del remoto origin) y `<miembro>` del remoto origin, así que los clones con fecha de `try clone` no ensucian las etiquetas.

### Configuración de Kinds por Rol

El tipo de agente a iniciar en cada rol se define mediante variables en un archivo de configuración:

- `PM_KIND`: Kind del agente para el rol PM (por ejemplo `"agy"`).
- `WK_KIND`: Kind del agente para el rol WK (por ejemplo `"agy"`).
- `RV_KIND`: Kind del agente para el rol RV (por ejemplo `"agy"`).

Si dejás un valor vacío (`""`), el tab correspondiente queda en un shell interactivo para que arranques el proceso manualmente.

El archivo de configuración se busca en el siguiente orden de precedencia:

1. Ruta definida en la variable de entorno `PJ_TRIO_CONFIG`.
2. Archivo `.trio/trio.conf` dentro del proyecto objetivo.
3. Archivo del sistema `/usr/share/ravn/trio/trio.conf`.
4. Archivo de respaldo `trio.conf.example` (junto a `pj-trio`).
5. Archivo `trio.conf.example` (junto a `pj-trio`) dentro del proyecto objetivo.

### Rol Directo y Verificación

Cuando el kind configurado es `agy`, cada tab arranca el agente directamente con su rol asignado (`--agent PM-<proyecto>`, `--agent WK-<proyecto>`, `--agent RV-<proyecto>`), sin pasar por menús interactivos ni selectores manuales.

Antes de inicializar, `pj-trio` consulta `agy agents` para verificar que los agentes del proyecto existan en el sistema (registrados en agy). Si alguno falta, la ejecución se detiene con un mensaje de error explícito.

### Integración Idempotente con herdr

Antes de arrancar los agentes, `pj-trio` verifica mediante `herdr integration status` que la integración correspondiente al kind (para `agy`, la definida en `TRIO_HERDR_INTEGRATION_AGY` de la config) esté instalada. Si falta, la instala automáticamente mediante `herdr integration install <target>`.

### Idempotencia

Si ejecutás `pj-trio` una segunda vez con los mismos argumentos:
- Detecta el workspace existente por su etiqueta.
- Reutiliza los tabs `pm`, `wk` y `rv` ya creados.
- No duplica procesos ni paneles de agentes en ejecución.
- Mantiene exactamente 3 tabs y 3 paneles en total, sin splits residuales ni paneles huérfanos.

### Worktree del WK

El PM crea un worktree nuevo por ticket (paso 2 de `trio-pm-prompt.md`) con [ravn-git-bare-clone](https://github.com/robert-flo/ravn-git-bare-clone) (ADR 0019 de pj-template) y el WK trabaja solo ahí; nunca se reutiliza uno viejo ni se usa `git worktree add` a mano:

- Preparación: `ravn-git-bare-clone clone <dueño>/<miembro>` (idempotente): bare en `$BARE_HOME/<miembro>.git` (`/z/bare`) y raíz de worktrees `$WORKTREES_HOME/<miembro>/` (`/z/repos`).
- Ruta: `/z/repos/<miembro>/<ticket>-<slug>`, con `git-create-worktree -r /z/repos/<miembro> -B <base> -b issue/<ticket>-<slug> -p '' <ticket>-<slug>` (mismo nombre que `git-issue-worktree`, pero sin pedir el issue al repo del código: en un home repo el issue vive en el meta-repo).
- Rama: `issue/<ticket>-<slug>` (si ya existe, otro slug).
- Base: `origin/<rama del spec>` con `--base` (sub-issue) u `origin/HEAD` sin `--base` (trivial).
- PR: el WK lo abre con `gh pr create -R <repo> --base '<rama del spec>'`. En un trivial lo abre sin `--base`, y gh usa la rama por defecto.
- Al cerrar: `git -C /z/repos/<miembro> worktree remove <ruta>`. El clon del miembro que encontró pj-trio es para leer.

### El PM maneja a WK y RV (#60)

- **Nombres de agente:** `pm|wk|rv-<miembro corto>-<ticket>` (o `<proyecto>` sin `--repo`), en minúsculas y saneados para herdr (≤32, `^[a-z][a-z0-9_-]*$`). Se quitan los prefijos `pj-domina-`, `rf-`, `fo-` (`rf-pj-domina-rf-git-setup` #3 → `pm-git-setup-3`); si aún no cabe se trunca y se agrega un hash de 4 caracteres. Es determinista: si ese ticket ya tiene su trío corriendo, `pj-trio` avisa y no lo duplica.
- **Arranque automático:** con `PM_KIND=agy`, `pj-trio` renderiza `trio-pm-prompt.md` en `<proyecto>/.trio/<ticket>/kickoff.md` y arranca el PM con `agy -i "Lee y segui … .trio/<ticket>/kickoff.md"` (una sola línea: herdr rechaza argumentos con saltos de línea). Un PM recién lanzado recibe siempre el arranque, aunque ya exista `status.json`, que se conserva para que retome desde ahí. Con otro kind, lo envía con `herdr agent prompt pm-<miembro corto>-<ticket> "…"` tras esperar a que el PM quede `idle` (`TRIO_READY_TIMEOUT`, 180 s); ahí el marcador es `status.json`: si existe, no se reenvía. Si agy muestra el diálogo «Do you trust the contents of this project?», avisa con `notify-send` y espera una tecla tuya (Enter) para continuar; esa pausa no la corta `TRIO_READY_TIMEOUT`. pj-trio no escribe la confianza de agy: la gestiona la workstation (`trustedWorkspaces` con `/z-drive/tries`). Si vence o el envío falla, pegá la salida de `pj-trio --print-kickoff …`.
- **Handoff único:** `<proyecto>/.trio/<ticket>/` con `plan.md`, `wk.md`, `rv.md` y `status.json`, commiteado en el meta-repo; nombra solo roles y nunca se duplica en los repos miembros.
- **El PM pinguea** a WK y RV con `herdr agent prompt`, espera con `herdr agent wait … --timeout 600000` (reintenta si falla) y confirma con `herdr agent read` más el archivo de entrega.
- **Quién mergea (ADR 0018 de pj-template, la regla de los tríos de fleet):** un sub-issue (`--base`) no pasa por RV: el WK mergea su PR a la rama del spec con CI verde y code-review limpio, y el PM lo confirma y cierra. Un trivial (o el PR final de la rama del spec) lo revisa RV y lo mergea el PM. RV nunca mergea.
- **Merge (el PM, tras el APRUEBO):** tras `APRUEBO <sha>` de RV, el PM mergea con `gh pr merge <pr> --squash --delete-branch --match-head-commit <sha>`, usando el sha que nombró RV. Si el head cambió después del APRUEBO, no mergea y pide otra revisión. Después cierra (status `hecho`, commit + push del meta-repo, `worktree remove`) y le avisa a Roberto con el link del PR, el link del APRUEBO, el sha del merge y los pasos de validación manual (ADR 0014 de pj-template).
- **Worktree nuevo por ticket**, siempre; ver [Worktree del WK](#worktree-del-wk).
- **Identidad git:** `TRIO_GIT_NAME`/`TRIO_GIT_EMAIL` de la config; `pj-trio` la fija con `git config` local en el meta-repo y el miembro (los worktrees la heredan). El PM no la toca.
- **Reintento y aviso (#61):** si un paso falla (wait con error o vencido; agente blocked, agent_prompt_stalled, unknown o ausente; idle sin archivo de entrega), el PM lo reintenta una sola vez. Si vuelve a fallar se detiene, escribe `status.json` con `needs-roberto` y la cola del panel, y lanza `notify-send`. Nunca responde por su cuenta un diálogo de aprobación. Las alertas al teléfono quedan fuera de alcance.
- **`trio-status`:** helper que escribe `status.json` y avisa:
  `trio-status [--dry-run] [--notify] [--cola-de <agente>] [--error <texto>] [--pr <url>] [--head <sha>] [--intentos N] <trio_dir> <estado> <paso>`.
  Esquema: `ticket`, `estado` (`en-curso`|`hecho`|`needs-roberto`), `paso` (`plan`|`wk`|`rv`|`merge`|`cierre`), `error`, `intentos`, `timestamp` (ISO 8601), `pr`, `head`, `cola`. Conserva las claves previas del archivo.
- **Prueba sin herdr:** `tests/test-pj-trio-dry-run.sh`.
